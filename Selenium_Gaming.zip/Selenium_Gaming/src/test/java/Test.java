import Checker_Game.Checker;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;

public class Test {

    WebDriver driver;
    @BeforeTest
    public void open_browser(){
        System.setProperty("web.chrome.driver","/Users/muralikrishna/Downloads/chrome-mac-x64/Google Chrome for Testing.app");
        driver = new ChromeDriver();
        driver.get("https://www.gamesforthebrain.com/game/checkers/");

    }

    @org.testng.annotations.Test
    public void test(){
        Checker obj = new Checker();
        PageFactory.initElements(driver, obj);
        obj.getcoins();

    }
}
