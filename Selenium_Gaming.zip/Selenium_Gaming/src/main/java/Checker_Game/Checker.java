package Checker_Game;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;


public class Checker {

    @FindBy(className = "boardWrapper")
    WebElement page_checkpoint;

    @FindBy(how = How.XPATH, using = "//img[@src='you1.gif']")
    List<WebElement> orange_coins;

    @FindBy(how = How.ID, using = "message")
    WebElement move_status;



    public void getcoins(){

        System.out.println(orange_coins.size());
        System.out.println(move_status.getText());
    }
}
